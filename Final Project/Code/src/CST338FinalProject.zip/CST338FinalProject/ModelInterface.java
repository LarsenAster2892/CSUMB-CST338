package CST338FinalProject;

import java.awt.Point;
/*
 * Subject: CST338 
 * Student: Clarence Mitchell
 * Assignment: Final Project 
 * ClassName: ModelInterface.java
 * 
 *
 * Description
 * Interface for model -- 
 * 
 */
public interface ModelInterface 
{
     public void movePlayer(Point location);
}
